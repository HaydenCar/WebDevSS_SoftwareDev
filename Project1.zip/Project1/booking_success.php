<?php require 'layout/header.php'; ?>

<!DOCTYPE html>
<html>
<head>
    <title>Booking Successful - HII Events</title>
</head>
<body>
<div class="booking-success-container">
    <h2>Your booking was successful!</h2>
    <p>Thank you for booking with HII Events. We can't wait to see you at the event!</p>
    <a href="index.php">Return to Home</a>
</div>
</body>
</html>
